Geographic data: two sample point locations.
